import logo from './logo.svg';
import './App.css';
import Loading1 from './Loading1';
 
function App() {
  return (
    <div className='bgcol'>
      <div className='text'>
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
      </header>
    </div>
    <p>LOADING</p>
    <p>SCREEN</p>
    <p>REACT</p>
    </div>
    <Loading1/>
    </div>
  );
}
 
export default App;