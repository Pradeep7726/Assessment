import './Loading1.css';
import React, { useEffect, useState } from "react";
function Loading1() {
    return (
<div className='cen'>
<div className="spinner">
<span>Loading...</span>
<div className="half-spinner"></div>
</div>
</div>
    );
}
 
export default Loading1;