import React from 'react';
import axios from 'axios';

export default class Axiexample extends React.Component {
  state = {
    persons: []
  }
  componentDidMount() {
    axios.get('https://datausa.io/api/data?drilldowns=Nation&measures=Population')
      .then(res => {
        const persons = res.data;
        console.log(this.state.persons)
        this.setState({ persons: persons.data });
      })
  }
  render() {
    return (
      <center>
        <div>
          <h1>Population Table</h1>
          <table border={"black"}>
            <thead>
              <tr>

                <th> ID Nation</th>
                <th> Population</th>
                <th> Year</th>
              </tr>
            </thead>
            <tbody>
              {
                this.state.persons
                  .map(person =>
                    <tr>
                      <td>01000US</td>
                      <td>{person.Population}</td>
                      <td>{person.Year}</td>
                    </tr>
                  )
              }
            </tbody>
          </table>
        </div>
      </center>
    )
  }
}